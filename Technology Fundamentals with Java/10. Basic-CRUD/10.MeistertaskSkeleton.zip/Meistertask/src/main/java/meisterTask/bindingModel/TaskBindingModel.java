package meisterTask.bindingModel;

public class TaskBindingModel {
    //TODO
}
